from setuptools import setup, find_packages

setup(
    name='models',
    version='1.0',
    packages=find_packages(),
    url = "https://bitbucket.org/tdross/code-collision-models/src/",
    description='Code Collision Models.',
    author='Tyler',
    install_requires=['flask==1.0.2', 'Flask-SQLAlchemy==2.3.2'],
)
